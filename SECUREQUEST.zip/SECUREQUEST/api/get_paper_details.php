<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
$conn = new mysqli("localhost", "root", "", "examportal");
$setID = $_POST['setID'];
$result = $conn->query("SELECT * FROM paper_set WHERE setID='$setID'");
echo json_encode($result->fetch_assoc());
?>