<?php
class Encryption {
    private static $key = 'SecureQuest2024';
    
    // Simple encryption (base64 + reverse)
    public static function encrypt($data) {
        if(empty($data)) return '';
        // Simple but working for demo
        return base64_encode(strrev($data));
    }
    
    public static function decrypt($encryptedData) {
        if(empty($encryptedData)) return '';
        // Reverse the process
        return strrev(base64_decode($encryptedData));
    }
}
?>