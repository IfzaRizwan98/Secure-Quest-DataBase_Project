<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$fullName = $_POST['fullName'];
$email = $_POST['email'];
$joiningDate = $_POST['joiningDate'];
$desiredRole = $_POST['role'];
$department = $_POST['department'];
$phoneNo = $_POST['phoneNo'];

$sql = "INSERT INTO registration_requests (fullName, email, joiningDate, desiredRole, department, phoneNo, status) 
        VALUES ('$fullName', '$email', '$joiningDate', '$desiredRole', '$department', '$phoneNo', 'pending')";

if($conn->query($sql) === TRUE) {
    echo '{"success": true, "message": "Registration request submitted successfully!"}';
} else {
    echo '{"success": false, "message": "Error: ' . $conn->error . '"}';
}
?>