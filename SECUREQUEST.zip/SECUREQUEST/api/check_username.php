<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$username = $_POST['username'];

// Check in both tables
$result1 = $conn->query("SELECT * FROM teacher WHERE username='$username'");
$result2 = $conn->query("SELECT * FROM exam_incharge WHERE username='$username'");

if($result1->num_rows > 0 || $result2->num_rows > 0) {
    echo json_encode(['exists' => true]);
} else {
    echo json_encode(['exists' => false]);
}
?>