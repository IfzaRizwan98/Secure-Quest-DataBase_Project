<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$userType = $_POST['userType'];
$userID = $_POST['userID'];
$username = $_POST['username'];
$action = $_POST['action'];

// Get client IP address
function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return $_SERVER['HTTP_X_FORWARDED_FOR'];
    return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
}
$ipAddress = getClientIP();

$sql = "INSERT INTO system_logs (userType, userID, username, action, ipAddress) 
        VALUES ('$userType', '$userID', '$username', '$action', '$ipAddress')";

if($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}
?>