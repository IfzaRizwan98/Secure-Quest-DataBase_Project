<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
require_once 'Encryption.php';

$conn = new mysqli("localhost", "root", "", "examportal");

$teacherID = $_POST['teacherID'] ?? 1;

$result = $conn->query("SELECT * FROM bank_questions WHERE teacherID='$teacherID' ORDER BY qID DESC");

$questions = [];
while($row = $result->fetch_assoc()) {
    $row['questionText'] = Encryption::decrypt($row['questionText']);
    $questions[] = $row;
}
echo json_encode($questions);
?>