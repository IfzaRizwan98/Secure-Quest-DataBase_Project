<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$username = $_POST['username'];
$currentPassword = $_POST['currentPassword'];
$newPassword = $_POST['newPassword'];

// Check current password
$result = $conn->query("SELECT * FROM admin WHERE username='$username' AND password='$currentPassword'");

if($result->num_rows > 0) {
    $sql = "UPDATE admin SET password='$newPassword' WHERE username='$username'";
    if($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Password changed successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error updating password']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Current password is incorrect']);
}
?>