<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$result = $conn->query("SELECT f.*, p.subjectName, p.semester, t.fullName as teacherName 
                        FROM finalized_paper f 
                        JOIN paper_set p ON f.setID = p.setID 
                        JOIN teacher t ON p.teacherID = t.teacherID 
                        ORDER BY f.approvedAt DESC");

$papers = [];
while($row = $result->fetch_assoc()) {
    $papers[] = $row;
}
echo json_encode($papers);
?>