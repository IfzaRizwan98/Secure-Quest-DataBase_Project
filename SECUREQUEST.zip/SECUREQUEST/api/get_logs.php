<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$result = $conn->query("SELECT * FROM system_logs ORDER BY logTime DESC LIMIT 500");

$logs = [];
while($row = $result->fetch_assoc()) {
    $logs[] = $row;
}
echo json_encode($logs);
?>