<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$setID = $_POST['setID'];

if(!$setID) {
    echo json_encode(['success' => false, 'message' => 'No setID provided']);
    exit();
}

$sql = "UPDATE paper_set SET status = 'pending' WHERE setID = '$setID'";

if($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true, 'message' => 'Paper submitted!']);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}
?>