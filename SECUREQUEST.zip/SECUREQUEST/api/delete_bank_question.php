<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$qID = $_POST['qID'];

$conn->query("DELETE FROM bank_questions WHERE qID='$qID'");

echo json_encode(['success' => true, 'message' => 'Deleted']);
?>