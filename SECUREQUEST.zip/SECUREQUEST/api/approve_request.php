<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$requestID = $_POST['requestID'];
$role = $_POST['role'];
$userId = $_POST['userId'];

$result = $conn->query("SELECT * FROM registration_requests WHERE requestID='$requestID'");
$req = $result->fetch_assoc();

if(!$req) {
    echo json_encode(['success' => false, 'message' => 'Request not found']);
    exit();
}

$defaultPassword = "12345";

if($role == 'teacher') {
    $sql = "INSERT INTO teacher (fullName, email, phoneNo, username, password, department, joiningDate, accountStatus) 
            VALUES ('{$req['fullName']}', '{$req['email']}', '{$req['phoneNo']}', '$userId', '$defaultPassword', '{$req['department']}', '{$req['joiningDate']}', 'active')";
} else {
    $sql = "INSERT INTO exam_incharge (fullName, email, phoneNo, username, password, department, accountStatus) 
            VALUES ('{$req['fullName']}', '{$req['email']}', '{$req['phoneNo']}', '$userId', '$defaultPassword', '{$req['department']}', 'active')";
}

if($conn->query($sql) === TRUE) {
    $conn->query("UPDATE registration_requests SET status='approved' WHERE requestID='$requestID'");
    echo json_encode(['success' => true, 'message' => 'User created! ID: ' . $userId . ', Pass: 12345']);
} else {
    echo json_encode(['success' => false, 'message' => 'DB Error: ' . $conn->error]);
}
?>