<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$users = [];
$result = $conn->query("SELECT teacherID as userId, fullName, email, username, phoneNo, 'teacher' as role FROM teacher WHERE accountStatus = 'blocked'");
while($row = $result->fetch_assoc()) $users[] = $row;
$result = $conn->query("SELECT inchargeID as userId, fullName, email, username, phoneNo, 'exam_incharge' as role FROM exam_incharge WHERE accountStatus = 'blocked'");
while($row = $result->fetch_assoc()) $users[] = $row;
echo json_encode($users);
?>