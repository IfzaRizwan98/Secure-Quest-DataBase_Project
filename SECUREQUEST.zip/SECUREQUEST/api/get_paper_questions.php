<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

require_once 'Encryption.php';

$conn = new mysqli("localhost", "root", "", "examportal");

$setID = $_POST['setID'];

$result = $conn->query("SELECT * FROM question WHERE setID='$setID' ORDER BY qID ASC");

$questions = [];
while($row = $result->fetch_assoc()) {
    $row['questionText'] = Encryption::decrypt($row['questionText']);
    $row['answer'] = Encryption::decrypt($row['answer']);
    $questions[] = $row;
}

echo json_encode($questions);
?>