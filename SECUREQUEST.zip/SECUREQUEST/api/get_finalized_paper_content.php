<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

require_once 'Encryption.php';

$conn = new mysqli("localhost", "root", "", "examportal");

$paperID = $_POST['paperID'] ?? $_GET['paperID'] ?? null;

if(!$paperID) {
    echo json_encode(['content' => 'No paperID provided']);
    exit();
}

$result = $conn->query("SELECT paperContent FROM finalized_paper WHERE paperID = " . intval($paperID));

if($result && $row = $result->fetch_assoc()) {
    $encryptedContent = $row['paperContent'];
    
    if(!empty($encryptedContent)) {
        $decryptedContent = Encryption::decrypt($encryptedContent);
        echo json_encode(['content' => $decryptedContent]);
    } else {
        echo json_encode(['content' => 'No content found']);
    }
} else {
    echo json_encode(['content' => 'No paper found']);
}
?>
