<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$username = $_POST['username'];
$password = $_POST['password'];

// Check admin
$result = $conn->query("SELECT * FROM admin WHERE username='$username' AND password='$password'");
if($result->num_rows > 0){
    echo json_encode(['success' => true, 'role' => 'admin', 'userID' => $username]);
    exit();
}

// Check teacher
$result = $conn->query("SELECT teacherID, username FROM teacher WHERE username='$username' AND password='$password' AND accountStatus='active'");
if($result->num_rows > 0){
    $row = $result->fetch_assoc();
    echo json_encode(['success' => true, 'role' => 'teacher', 'userID' => $row['teacherID'], 'username' => $row['username']]);
    exit();
}

// Check exam incharge
$result = $conn->query("SELECT inchargeID, username FROM exam_incharge WHERE username='$username' AND password='$password' AND accountStatus='active'");
if($result->num_rows > 0){
    $row = $result->fetch_assoc();
    echo json_encode(['success' => true, 'role' => 'exam_incharge', 'userID' => $row['inchargeID'], 'username' => $row['username']]);
    exit();
}

echo json_encode(['success' => false, 'message' => 'Invalid ID or Password']);
?>