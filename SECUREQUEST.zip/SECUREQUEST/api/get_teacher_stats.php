<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
$conn = new mysqli("localhost", "root", "", "examportal");
$teacherID = $_POST['teacherID'];
$total = $conn->query("SELECT COUNT(*) as c FROM paper_set WHERE teacherID='$teacherID'")->fetch_assoc()['c'];
$approved = $conn->query("SELECT COUNT(*) as c FROM paper_set WHERE teacherID='$teacherID' AND status='approved'")->fetch_assoc()['c'];
$pending = $conn->query("SELECT COUNT(*) as c FROM paper_set WHERE teacherID='$teacherID' AND status='pending'")->fetch_assoc()['c'];
$rejected = $conn->query("SELECT COUNT(*) as c FROM paper_set WHERE teacherID='$teacherID' AND status='disapproved'")->fetch_assoc()['c'];
echo json_encode(['success' => true, 'totalPapers' => $total, 'approvedPapers' => $approved, 'pendingPapers' => $pending, 'rejectedPapers' => $rejected]);
?>