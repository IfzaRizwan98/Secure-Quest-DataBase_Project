<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$thirtyMinsAgo = date('Y-m-d H:i:s', strtotime('-30 minutes'));
$result = $conn->query("SELECT COUNT(DISTINCT username) as active FROM system_logs WHERE logTime > '$thirtyMinsAgo' AND action LIKE 'Logged in'");

echo json_encode([
    'success' => true,
    'activeSessions' => $result->fetch_assoc()['active']
]);
?>