<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

// Total Users (Admin + Teacher + Exam Incharge)
$adminCount = $conn->query("SELECT COUNT(*) as count FROM admin")->fetch_assoc()['count'];
$teacherCount = $conn->query("SELECT COUNT(*) as count FROM teacher WHERE accountStatus = 'active'")->fetch_assoc()['count'];
$inchargeCount = $conn->query("SELECT COUNT(*) as count FROM exam_incharge WHERE accountStatus = 'active'")->fetch_assoc()['count'];
$totalUsers = $adminCount + $teacherCount + $inchargeCount;

// Total Teachers (all active teachers)
$totalTeachers = $teacherCount;

// Total Exam Incharge
$totalIncharge = $inchargeCount;

// Active Sessions (last 30 minutes)
$thirtyMinsAgo = date('Y-m-d H:i:s', strtotime('-30 minutes'));
$activeResult = $conn->query("SELECT COUNT(DISTINCT username) as active FROM system_logs WHERE logTime > '$thirtyMinsAgo' AND action LIKE 'Logged in'");
$activeSessions = $activeResult->fetch_assoc()['active'];

echo json_encode([
    'success' => true,
    'totalUsers' => $totalUsers,
    'totalTeachers' => $totalTeachers,
    'totalIncharge' => $totalIncharge,
    'activeSessions' => $activeSessions
]);
?>