<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$teacherID = $_POST['teacherID'];
$fullName = $_POST['fullName'];
$email = $_POST['email'];
$phoneNo = $_POST['phoneNo'];
$qualification = $_POST['qualification'];
$department = $_POST['department'];
$joiningDate = $_POST['joiningDate'];

$sql = "UPDATE teacher SET 
            fullName='$fullName', 
            email='$email', 
            phoneNo='$phoneNo', 
            qualification='$qualification', 
            department='$department', 
            joiningDate='$joiningDate' 
        WHERE teacherID='$teacherID'";

if($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true, 'message' => 'Profile updated']);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}
?>