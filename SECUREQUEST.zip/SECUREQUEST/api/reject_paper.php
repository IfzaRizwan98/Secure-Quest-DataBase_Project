<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
$conn = new mysqli("localhost", "root", "", "examportal");
$setID = $_POST['setID'];
$comment = $_POST['comment'] ?? '';

$conn->query("UPDATE paper_set SET status='disapproved', review_comment='$comment' WHERE setID='$setID'");

echo json_encode(['success' => true, 'message' => 'Paper rejected with feedback']);
?>