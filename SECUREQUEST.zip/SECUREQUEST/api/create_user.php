<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$fullName = $_POST['fullName'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];
$department = $_POST['department'];
$phoneNo = $_POST['phoneNo'];
$joiningDate = $_POST['joiningDate'];

if($role == 'teacher') {
    $sql = "INSERT INTO teacher (fullName, email, username, password, department, phoneNo, joiningDate, accountStatus) 
            VALUES ('$fullName', '$email', '$username', '$password', '$department', '$phoneNo', '$joiningDate', 'active')";
} else {
    $sql = "INSERT INTO exam_incharge (fullName, email, username, password, department, phoneNo, accountStatus) 
            VALUES ('$fullName', '$email', '$username', '$password', '$department', '$phoneNo', 'active')";
}

if($conn->query($sql) === TRUE) {
    echo '{"success": true, "message": "User account created successfully!"}';
} else {
    echo '{"success": false, "message": "Error: ' . $conn->error . '"}';
}
?>