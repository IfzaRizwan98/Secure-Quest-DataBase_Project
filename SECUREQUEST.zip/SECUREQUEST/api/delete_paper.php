<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$setID = $_POST['setID'];

// Questions will auto delete due to ON DELETE CASCADE
$sql = "DELETE FROM paper_set WHERE setID = '$setID'";

if($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true, 'message' => 'Paper deleted successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
}
?>