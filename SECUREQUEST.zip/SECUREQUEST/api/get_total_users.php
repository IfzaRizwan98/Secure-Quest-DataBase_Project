<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$users = [];

// Admins
$result = $conn->query("SELECT adminID as userId, fullName, email, username, phoneNo, 'admin' as role, 'active' as status FROM admin");
while($row = $result->fetch_assoc()) $users[] = $row;

// Teachers
$result = $conn->query("SELECT teacherID as userId, fullName, email, username, phoneNo, 'teacher' as role, accountStatus as status FROM teacher");
while($row = $result->fetch_assoc()) $users[] = $row;

// Exam Incharges
$result = $conn->query("SELECT inchargeID as userId, fullName, email, username, phoneNo, 'exam_incharge' as role, accountStatus as status FROM exam_incharge");
while($row = $result->fetch_assoc()) $users[] = $row;

echo json_encode($users);
?>