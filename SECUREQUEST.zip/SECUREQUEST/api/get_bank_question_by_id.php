<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
require_once 'Encryption.php';

$conn = new mysqli("localhost", "root", "", "examportal");

$qID = $_POST['qID'];
$teacherID = $_POST['teacherID'];

$result = $conn->query("SELECT * FROM bank_questions WHERE qID='$qID' AND teacherID='$teacherID'");
$row = $result->fetch_assoc();

if($row) {
    $row['questionText'] = Encryption::decrypt($row['questionText']);
    $row['answer'] = Encryption::decrypt($row['answer']);
    echo json_encode($row);
} else {
    echo json_encode(['error' => 'Question not found']);
}
?>