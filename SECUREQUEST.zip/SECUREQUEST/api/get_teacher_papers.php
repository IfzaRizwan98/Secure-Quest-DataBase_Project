<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
$conn = new mysqli("localhost", "root", "", "examportal");
$teacherID = $_POST['teacherID'];
$result = $conn->query("SELECT * FROM paper_set WHERE teacherID='$teacherID' ORDER BY submittedAt DESC");
$papers = []; while($row = $result->fetch_assoc()) $papers[] = $row;
echo json_encode($papers);
?>