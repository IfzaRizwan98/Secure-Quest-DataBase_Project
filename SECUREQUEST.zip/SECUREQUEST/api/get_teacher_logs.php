<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$teacherID = $_POST['teacherID'];

$result = $conn->query("SELECT * FROM system_logs WHERE userID='$teacherID' AND userType='teacher' ORDER BY logTime DESC LIMIT 5");

$logs = [];
while($row = $result->fetch_assoc()) {
    $logs[] = $row;
}
echo json_encode($logs);
?>