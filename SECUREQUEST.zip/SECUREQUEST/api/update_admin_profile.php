<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$username = $_POST['username'];
$fullName = $_POST['fullName'];
$email = $_POST['email'];
$phoneNo = $_POST['phoneNo'];
$department = $_POST['department'];
$joiningDate = $_POST['joiningDate'];

$sql = "UPDATE admin SET 
            fullName='$fullName', 
            email='$email', 
            phoneNo='$phoneNo', 
            department='$department', 
            joiningDate='$joiningDate' 
        WHERE username='$username'";

if($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
}
?>