<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$role = $_POST['role'];
$userId = $_POST['userId'];
$action = $_POST['action'];
$status = ($action == 'block') ? 'blocked' : 'active';

if($role == 'teacher') {
    $sql = "UPDATE teacher SET accountStatus = '$status' WHERE teacherID = $userId";
} else if($role == 'exam_incharge') {
    $sql = "UPDATE exam_incharge SET accountStatus = '$status' WHERE inchargeID = $userId";
} else {
    echo json_encode(['success' => false, 'message' => 'Admin cannot be blocked']);
    exit();
}

if($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true, 'message' => 'User ' . $action . 'ed successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
}
?>