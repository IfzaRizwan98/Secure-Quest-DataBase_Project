<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$username = $_POST['username'];

$result = $conn->query("SELECT adminID, username, fullName, email, phoneNo, department, joiningDate FROM admin WHERE username='$username'");
$row = $result->fetch_assoc();

if($row) {
    echo json_encode([
        'success' => true,
        'adminID' => $row['adminID'],
        'username' => $row['username'],
        'fullName' => $row['fullName'],
        'email' => $row['email'],
        'phoneNo' => $row['phoneNo'],
        'department' => $row['department'],
        'joiningDate' => $row['joiningDate']
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Admin not found']);
}
?>