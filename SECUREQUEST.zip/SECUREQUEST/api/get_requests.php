<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$result = $conn->query("SELECT * FROM registration_requests WHERE status='pending' ORDER BY submittedAt DESC");

$requests = [];
while($row = $result->fetch_assoc()) {
    $requests[] = $row;
}
echo json_encode($requests);
?>