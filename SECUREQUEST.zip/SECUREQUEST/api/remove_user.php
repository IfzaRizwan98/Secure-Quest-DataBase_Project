<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$role = $_POST['role'];
$userId = $_POST['userId'];

if($role == 'teacher') {
    $sql = "DELETE FROM teacher WHERE teacherID = $userId";
} else if($role == 'exam_incharge') {
    $sql = "DELETE FROM exam_incharge WHERE inchargeID = $userId";
} else {
    echo json_encode(['success' => false, 'message' => 'Admin cannot be removed']);
    exit();
}

if($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true, 'message' => $role . ' removed successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
}
?>