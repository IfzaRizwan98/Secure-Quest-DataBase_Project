<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

require_once 'Encryption.php';

$conn = new mysqli("localhost", "root", "", "examportal");

$setID = $_POST['setID'];
$comment = $_POST['comment'] ?? '';

$conn->query("UPDATE paper_set SET status='approved', review_comment='$comment' WHERE setID='$setID'");

// Get questions and decrypt
$questionsRes = $conn->query("SELECT * FROM question WHERE setID='$setID'");
$paperContent = "EXAMINATION PAPER\n\n";
$qNo = 1;

while($q = $questionsRes->fetch_assoc()) {
    // Decrypt using our simple method
    $text = Encryption::decrypt($q['questionText']);
    $paperContent .= "Q" . $qNo . ". " . $text . " (" . $q['marks'] . " marks)\n\n";
    $qNo++;
}

// Store encrypted (using same simple method)
$encryptedPaperContent = Encryption::encrypt($paperContent);

$conn->query("DELETE FROM finalized_paper WHERE setID='$setID'");
$conn->query("INSERT INTO finalized_paper (setID, paperContent) VALUES ('$setID', '$encryptedPaperContent')");

echo json_encode(['success' => true, 'message' => 'Paper approved']);
?>