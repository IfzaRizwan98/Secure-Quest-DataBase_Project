<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
$conn = new mysqli("localhost", "root", "", "examportal");
$teacherID = $_POST['teacherID'];
$department = $_POST['department'];
$semester = $_POST['semester'];
$subjectCode = $_POST['subjectCode'];
$subjectName = $_POST['subjectName'];
$totalMarks = $_POST['totalMarks'];
$allowedTime = $_POST['allowedTime'];
$mcqLimit = $_POST['mcqLimit'];
$shortLimit = $_POST['shortLimit'];
$longLimit = $_POST['longLimit'];
$sql = "INSERT INTO paper_set (teacherID, department, semester, subjectCode, subjectName, totalMarks, allowedTime, mcqLimit, shortLimit, longLimit, status) VALUES ('$teacherID','$department','$semester','$subjectCode','$subjectName','$totalMarks','$allowedTime','$mcqLimit','$shortLimit','$longLimit','draft')";
if($conn->query($sql) === TRUE) echo json_encode(['success' => true, 'setID' => $conn->insert_id]);
else echo json_encode(['success' => false, 'message' => $conn->error]);
?>