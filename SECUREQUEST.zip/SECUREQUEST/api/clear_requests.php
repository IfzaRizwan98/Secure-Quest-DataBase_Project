<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$conn->query("DELETE FROM registration_requests WHERE status='pending'");

echo json_encode(['success' => true, 'message' => 'All pending requests cleared']);
?>