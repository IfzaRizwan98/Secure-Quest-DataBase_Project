<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$userId = $_POST['userId'];
$phoneNo = $_POST['phoneNo'];
$newPassword = $_POST['newPassword'];

$updated = false;

// Check in admin table
$result = $conn->query("SELECT * FROM admin WHERE username='$userId' AND phoneNo='$phoneNo'");
if($result->num_rows > 0) {
    $conn->query("UPDATE admin SET password='$newPassword' WHERE username='$userId'");
    $updated = true;
}

// Check in teacher table
if(!$updated) {
    $result = $conn->query("SELECT * FROM teacher WHERE username='$userId' AND phoneNo='$phoneNo'");
    if($result->num_rows > 0) {
        $conn->query("UPDATE teacher SET password='$newPassword' WHERE username='$userId'");
        $updated = true;
    }
}

// Check in exam_incharge table
if(!$updated) {
    $result = $conn->query("SELECT * FROM exam_incharge WHERE username='$userId' AND phoneNo='$phoneNo'");
    if($result->num_rows > 0) {
        $conn->query("UPDATE exam_incharge SET password='$newPassword' WHERE username='$userId'");
        $updated = true;
    }
}

if($updated) {
    echo json_encode(['success' => true, 'message' => 'Password reset successful!']);
} else {
    echo json_encode(['success' => false, 'message' => 'User ID and Phone Number do not match!']);
}
?>