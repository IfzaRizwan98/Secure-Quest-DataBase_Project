<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$result = $conn->query("SELECT p.*, t.fullName as teacherName 
                        FROM paper_set p 
                        JOIN teacher t ON p.teacherID = t.teacherID 
                        WHERE p.status = 'pending' 
                        ORDER BY p.submittedAt DESC");

$papers = [];
while($row = $result->fetch_assoc()) {
    $papers[] = $row;
}
echo json_encode($papers);
?>