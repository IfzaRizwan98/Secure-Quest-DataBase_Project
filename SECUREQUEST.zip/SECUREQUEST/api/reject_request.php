<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$requestID = $_POST['requestID'];

$conn->query("UPDATE registration_requests SET status='rejected' WHERE requestID='$requestID'");

echo json_encode(['success' => true, 'message' => 'Request rejected']);
?>