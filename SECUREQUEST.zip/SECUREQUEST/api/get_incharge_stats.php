<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
$conn = new mysqli("localhost", "root", "", "examportal");
$pending = $conn->query("SELECT COUNT(*) as c FROM paper_set WHERE status='pending'")->fetch_assoc()['c'];
$approved = $conn->query("SELECT COUNT(*) as c FROM paper_set WHERE status='approved'")->fetch_assoc()['c'];
echo json_encode(['pendingCount' => $pending, 'approvedCount' => $approved]);
?>