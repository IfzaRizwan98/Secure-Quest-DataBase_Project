<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$teacherID = $_POST['teacherID'];

$result = $conn->query("SELECT teacherID, username, fullName, email, phoneNo, qualification, department, joiningDate FROM teacher WHERE teacherID='$teacherID'");
$row = $result->fetch_assoc();

echo json_encode($row);
?>