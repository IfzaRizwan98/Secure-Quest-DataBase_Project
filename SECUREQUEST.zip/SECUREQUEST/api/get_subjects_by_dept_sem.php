<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$deptID = $_POST['deptID'];
$semesterNumber = $_POST['semesterNumber'];

// Get semesterID from deptID and semesterNumber
$semResult = $conn->query("SELECT semesterID FROM semester WHERE deptID='$deptID' AND semesterNumber='$semesterNumber'");
$semRow = $semResult->fetch_assoc();
$semesterID = $semRow['semesterID'] ?? 1;

// Get subjects for that semester
$result = $conn->query("SELECT subjectCode, subjectName FROM subject WHERE semesterID='$semesterID' ORDER BY subjectCode");

$subjects = [];
while($row = $result->fetch_assoc()) {
    $subjects[] = $row;
}
echo json_encode($subjects);
?>