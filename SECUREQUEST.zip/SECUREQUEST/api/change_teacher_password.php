<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$teacherID = $_POST['teacherID'];
$currentPassword = $_POST['currentPassword'];
$newPassword = $_POST['newPassword'];

// Check current password
$result = $conn->query("SELECT * FROM teacher WHERE teacherID='$teacherID' AND password='$currentPassword'");

if($result->num_rows > 0) {
    $sql = "UPDATE teacher SET password='$newPassword' WHERE teacherID='$teacherID'";
    if($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Password changed successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error updating password']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Current password is incorrect']);
}
?>