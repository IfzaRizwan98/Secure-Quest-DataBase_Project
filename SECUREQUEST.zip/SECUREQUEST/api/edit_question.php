<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
require_once 'Encryption.php';

$conn = new mysqli("localhost", "root", "", "examportal");

$qID = $_POST['qID'];
$questionText = $_POST['questionText'];
$marks = $_POST['marks'];

$encryptedText = Encryption::encrypt($questionText);

$sql = "UPDATE question SET questionText='$encryptedText', marks='$marks' WHERE qID='$qID'";

if($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true, 'message' => 'Updated']);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}
?>