<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

require_once 'Encryption.php';

$conn = new mysqli("localhost", "root", "", "examportal");

$setID = $_POST['setID'];
$questionText = $_POST['questionText'];
$questionType = $_POST['questionType'];
$answer = $_POST['answer'];
$marks = $_POST['marks'];

$encryptedText = Encryption::encrypt($questionText);
$encryptedAnswer = Encryption::encrypt($answer);

$sql = "INSERT INTO question (setID, questionText, questionType, answer, marks) 
        VALUES ('$setID', '$encryptedText', '$questionType', '$encryptedAnswer', '$marks')";

if($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true, 'message' => 'Saved']);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}
?>