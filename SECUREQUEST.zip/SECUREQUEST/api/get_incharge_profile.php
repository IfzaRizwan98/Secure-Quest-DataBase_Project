<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$inchargeID = $_POST['inchargeID'] ?? $_GET['inchargeID'] ?? null;

if(!$inchargeID) {
    echo json_encode(['error' => 'No inchargeID provided']);
    exit();
}

$result = $conn->query("SELECT inchargeID, username, fullName, email, phoneNo, qualification, department, joiningDate FROM exam_incharge WHERE inchargeID = '$inchargeID'");

if($result && $row = $result->fetch_assoc()) {
    echo json_encode($row);
} else {
    echo json_encode(['error' => 'No data found for ID: ' . $inchargeID]);
}
?>