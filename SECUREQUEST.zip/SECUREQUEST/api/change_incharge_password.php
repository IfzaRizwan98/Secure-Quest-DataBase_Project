<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "examportal");

$inchargeID = $_POST['inchargeID'];
$currentPassword = $_POST['currentPassword'];
$newPassword = $_POST['newPassword'];

$result = $conn->query("SELECT * FROM exam_incharge WHERE inchargeID='$inchargeID' AND password='$currentPassword'");

if($result->num_rows > 0) {
    $sql = "UPDATE exam_incharge SET password='$newPassword' WHERE inchargeID='$inchargeID'";
    if($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Password changed successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error updating password']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Current password is incorrect']);
}
?>